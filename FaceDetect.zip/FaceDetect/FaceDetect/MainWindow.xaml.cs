﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.ProjectOxford.Face;
using Microsoft.ProjectOxford.Face.Contract;
using System.Windows.Media.Imaging;
using System.Windows;
using AForge.Controls;
using Microsoft.VisualBasic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using System.Collections.ObjectModel;
using System.Reflection;

namespace FaceDetect
{
    public partial class MainWindow : Window
    {
        private readonly IFaceServiceClient faceServiceClient =
           new FaceServiceClient("d281ad0181c0479fbdf64f1d19f30252", "https://api.cognitive.azure.cn/face/v1.0");
        Face[] faces;                                // The list of detected faces.
        string[] imagesPath;
        double resizeFactor;                         // The resize factor for the displayed image.
        private DispatcherTimer dispatcherTimer;     //display currenttime
        private string image;                        //define the imagepath
        string personGroupID = "test1";              //define the personGroupId
        public static User user;                    //定义一个人员对象
        public static ObservableCollection<User> UserGroup = new ObservableCollection<User>();
        public MainWindow()
        {
            InitializeComponent();
            InitialTime();                          //显示时间
            SqlHelper a = new SqlHelper();
        } 

        private void InitialTime()                                      //初始化计时器
        {
            dispatcherTimer = new DispatcherTimer();
            // 当间隔时间过去时发生的事件
            dispatcherTimer.Tick += new EventHandler(ShowCurrentTime);
            dispatcherTimer.Interval = new TimeSpan(0, 0, 0, 1);
            dispatcherTimer.Start();
        }

        public void ShowCurrentTime(object sender, EventArgs e)
        {
            //显示的时间格式
            //获得星期
            //this.tBlockTime.Text = DateTime.Now.ToString("dddd", new System.Globalization.CultureInfo("zh-cn"));
            //this.tBlockTime.Text += "\n";

            //获得年月日
            //this.tBlockTime.Text = DateTime.Now.ToString("yyyy:MM:dd");   //yyyy年MM月dd日
            //this.tBlockTime.Text += "\n";

            //获得时分秒
            this.tBlockTime.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss dddd");
        }

        //录入键
        private async void LuRu_Click(object sender, RoutedEventArgs e)
        {
            Add.IsEnabled = false;
            if ((bool)Picture.IsChecked)                                //判断照片识别的勾是否被选中
            {
                bool isAdded = await AddPerson(user);                   //判断人员是否创建成功
                if (isAdded)
                {
                    MessageBox.Show("上传成功");
                }
                else
                {
                    MessageBox.Show("上传失败");
                    return;
                }
            }
            else if ((bool)Camera.IsChecked)                           //判断现场拍摄的勾是否被选中
            {
                bool isAdded = await AddPerson(personGroupID, image);
                if (isAdded)
                {
                    MessageBox.Show("上传成功");
                }
                else
                {
                    MessageBox.Show("上传失败");
                    return;
                }
                

            }
            UserGroup.Add(user);
            (new SqlHelper()).UpdateDataBase();
            
        }
        //上传图片并识别 返回相应的脸部信息

        private async Task<Face[]> UploadAndDetectFaces(string imageFilePath)
        {
            // The list of Face attributes to return.
            IEnumerable<FaceAttributeType> faceAttributes =
                new FaceAttributeType[] { FaceAttributeType.Gender, FaceAttributeType.Age, FaceAttributeType.Emotion };

            // Call the Face API.
            try
            {
                using (Stream imageFileStream = File.OpenRead(imageFilePath))
                {
                    Face[] faces = await faceServiceClient.DetectAsync(imageFileStream, returnFaceId: true, returnFaceLandmarks: false, returnFaceAttributes: faceAttributes);
                    return faces;
                }
            }
            // Catch and display Face API errors.
            catch (FaceAPIException f)
            {
                MessageBox.Show(f.ErrorMessage, f.ErrorCode);
                return new Face[0];
            }
            // Catch and display all other errors.
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error");
                return new Face[0];
            }
        }
        //关闭程序释放摄像头资源
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            CameraHelper.CloseDevice();
        }

        private void OpenCamera(VideoSourcePlayer player)
        {
            CameraHelper.IsDisplay = true;
            CameraHelper.SourcePlayer = player;
            CameraHelper.UpdateCameraDevices();
            if (CameraHelper.CameraDevices.Count > 0)
            {
                CameraHelper.SetCameraDevice(0);
            }
            else
            {
                MessageBox.Show("抱歉，您没有可用的摄像头");
            }
        }

        private void CloseCamera()
        {
            CameraHelper.IsDisplay = false;
            CameraHelper.SourcePlayer = null;
            CameraHelper.CloseDevice();
        }
   
        //签到按钮
        private async void QianDao_Click(object sender, RoutedEventArgs e)
        {
            if(!await Identity(image))
            {
                MessageBox.Show("签到失败,该人员不存在");
                return;
            }

        }


        private void CreatePersonGroup1Async(string personGroupID)
        {
            IFaceServiceClient faceServiceClient2 =
            new FaceServiceClient("d281ad0181c0479fbdf64f1d19f30252", "https://api.cognitive.azure.cn/face/v1.0");
            faceServiceClient2.CreatePersonGroupAsync(personGroupID, personGroupID);
            MessageBox.Show("ok");
        }
            
        private async Task<bool> DetectPictureAndImformation(string imagePath)
        {
            FacePhoto.Visibility = Visibility.Visible;
            Uri fileUri = new Uri(imagePath);
            BitmapImage bitmapSource = new BitmapImage();
            bitmapSource.BeginInit();
            bitmapSource.CacheOption = BitmapCacheOption.None;
            bitmapSource.UriSource = fileUri;
            bitmapSource.EndInit();
            FacePhoto.Source = bitmapSource;

            // Detect any faces in the image.
            faces = await UploadAndDetectFaces(imagePath);
            if (faces.Length != 1)
            {
                if (faces.Length < 1)
                    MessageBox.Show("温馨提示：未识别到人脸，原因：图片不够清晰或图片中没有人脸，请您重新选择");
                else
                    MessageBox.Show("温馨提示：传入图片中的人脸数量只能为1个，请您重新选择");
                return false;
            }
            else
            {
                if (faces.Length > 0)
                {
                    // Prepare to draw rectangles around the faces.
                    DrawingVisual visual = new DrawingVisual();
                    DrawingContext drawingContext = visual.RenderOpen();
                    drawingContext.DrawImage(bitmapSource,
                                        new Rect(0, 0, bitmapSource.Width, bitmapSource.Height));
                    double dpi = bitmapSource.DpiX;
                    resizeFactor = 96 / dpi;
                    for (int i = 0; i < faces.Length; ++i)
                    {
                        Face face = faces[i];

                        // Draw a rectangle on the face.
                        drawingContext.DrawRectangle(
                            Brushes.Transparent,
                                                new Pen(Brushes.Red, 2),
                                                new Rect(
                                                    face.FaceRectangle.Left * resizeFactor,
                                                    face.FaceRectangle.Top * resizeFactor,
                                                    face.FaceRectangle.Width * resizeFactor,
                                                    face.FaceRectangle.Height * resizeFactor
                                                    )
                                            );

                        // Store the face description.
                    }

                    drawingContext.Close();

                    // Display the image with the rectangle around the face.
                    RenderTargetBitmap faceWithRectBitmap = new RenderTargetBitmap(
                        (int)(bitmapSource.PixelWidth * resizeFactor),
                        (int)(bitmapSource.PixelHeight * resizeFactor),
                        96,
                        96,
                        PixelFormats.Pbgra32);

                    faceWithRectBitmap.Render(visual);
                    FacePhoto.Source = faceWithRectBitmap;

                    // Set the status bar text.
                }
                MessageBox.Show("识成别功");
                user = new User
                {
                    Sex = faces[0].FaceAttributes.Gender,
                    Age = faces[0].FaceAttributes.Age,
                    Emotion = faces[0].FaceAttributes.Emotion.ToRankedList().First().Key
                };
                (new InputName()).ShowDialog();
                if (user.Name == null || user.Name.Trim().Equals(""))
                {
                    MessageBox.Show("录入失败，请输入有效的姓名");
                    return false;
                }
                this.DataContext = user;
                return true;

            }
        }

        private async Task<bool> DetectPicture(string imagePath)
        {
            Uri fileUri = new Uri(imagePath);
            BitmapImage bitmapSource = new BitmapImage();
            bitmapSource.BeginInit();
            bitmapSource.CacheOption = BitmapCacheOption.None;
            bitmapSource.UriSource = fileUri;
            bitmapSource.EndInit();
            FacePhoto1.Source = bitmapSource;

            // Detect any faces in the image.
            faces = await UploadAndDetectFaces(imagePath);
            if (faces.Length != 1)
            {
                if (faces.Length < 1)
                    MessageBox.Show("温馨提示：未识别到人脸，原因：图片不够清晰或图片中没有人脸，请您重新选择");
                else
                    MessageBox.Show("温馨提示：传入图片中的人脸数量只能为1个，请您重新选择");
                return false;
            }
            else
            {
                MessageBox.Show("温馨提示：人像识别成功");
                if (faces.Length > 0)
                {
                    // Prepare to draw rectangles around the faces.
                    DrawingVisual visual = new DrawingVisual();
                    DrawingContext drawingContext = visual.RenderOpen();
                    drawingContext.DrawImage(bitmapSource,
                                        new Rect(0, 0, bitmapSource.Width, bitmapSource.Height));
                    double dpi = bitmapSource.DpiX;
                    resizeFactor = 96 / dpi;
                    for (int i = 0; i < faces.Length; ++i)
                    {
                        Face face = faces[i];

                        // Draw a rectangle on the face.
                        drawingContext.DrawRectangle(
                            Brushes.Transparent,
                                                new Pen(Brushes.Red, 2),
                                                new Rect(
                                                    face.FaceRectangle.Left * resizeFactor,
                                                    face.FaceRectangle.Top * resizeFactor,
                                                    face.FaceRectangle.Width * resizeFactor,
                                                    face.FaceRectangle.Height * resizeFactor
                                                    )
                                            );

                        // Store the face description.
                    }

                    drawingContext.Close();

                    // Display the image with the rectangle around the face.
                    RenderTargetBitmap faceWithRectBitmap = new RenderTargetBitmap(
                        (int)(bitmapSource.PixelWidth * resizeFactor),
                        (int)(bitmapSource.PixelHeight * resizeFactor),
                        96,
                        96,
                        PixelFormats.Pbgra32);

                    faceWithRectBitmap.Render(visual);
                    FacePhoto1.Source = faceWithRectBitmap;

                    // Set the status bar text.
                }
                return true;
            }
        }

        private async Task<bool> AddPerson(User user)
        {

            CreatePersonResult person = await faceServiceClient.CreatePersonInPersonGroupAsync(personGroupID, user.Name);   //向云端发出注册人员的请求          
            foreach (string image in imagesPath)                   
            {
                using (Stream s = File.OpenRead(image))          //都能识别的话则向云端的该人员上传相应的照片
                {
                    await faceServiceClient.AddPersonFaceInPersonGroupAsync(         
                        personGroupID, person.PersonId, s);
                }
            }
           /* TrainingStatus trainingStatus = null;
            while (true)
            {
                trainingStatus = await faceServiceClient.GetPersonGroupTrainingStatusAsync(personGroupID);

                if (trainingStatus.Status != Status.Running)
                {
                    break;
                }

                await Task.Delay(1000);
            }*/
            await faceServiceClient.TrainPersonGroupAsync(personGroupID);   //交给云端训练
            return true;


        }

        private async Task<bool> AddPerson(string name, string image)
        {

            CreatePersonResult person = await faceServiceClient.CreatePersonInPersonGroupAsync(personGroupID, name);
            using (Stream s = File.OpenRead(image))
            {
                await faceServiceClient.AddPersonFaceInPersonGroupAsync(
                    personGroupID, person.PersonId, s);
            }
            await faceServiceClient.TrainPersonGroupAsync(personGroupID);
            /*TrainingStatus trainingStatus = null;
            while (true)
            {
                trainingStatus = await faceServiceClient.GetPersonGroupTrainingStatusAsync(personGroupID);

                if (trainingStatus.Status != Status.Running)
                {
                    break;
                }

                await Task.Delay(1000);
            }*/
            return true;
        }

        private async Task<bool> Identity(string imagePath)
        {

            using (Stream s = File.OpenRead(imagePath))
            {
                var faces = await faceServiceClient.DetectAsync(s);
                var faceIds = faces.Select(face => face.FaceId).ToArray();
                var results = await faceServiceClient.IdentifyAsync(personGroupID, faceIds);
                foreach (var identifyResult in results)
                {
                    if (identifyResult.Candidates.Length == 0)
                    {
                        return false;
                    }
                    else
                    {
                        // Get top 1 among all candidates returned
                        /*var candidateId = identifyResult.Candidates[0].PersonId;
                        var person = await faceServiceClient.GetPersonInPersonGroupAsync(personGroupID, candidateId);*/
                        MessageBox.Show("恭喜你签到成功" );
                        return true;
                    }
                }
            }
            return false;
        }

        private void Picture_Checked(object sender, RoutedEventArgs e)
        {
            Capture1.IsEnabled = false;
            ReCapture1.IsEnabled = false;
            Add.IsEnabled = false;
            SelectFile.IsEnabled = true;
            CloseCamera();
            Video.Visibility = Visibility.Hidden;
            FacePhoto.Visibility = Visibility.Collapsed;
            player.Visible = false;         
        }

        private void Camera_Checked(object sender, RoutedEventArgs e)
        {
            Capture1.IsEnabled = true;
            ReCapture1.IsEnabled = false;
            Add.IsEnabled = false;
            SelectFile.IsEnabled = false;
            FacePhoto.Visibility = Visibility.Collapsed;
            Video.Visibility = Visibility.Visible;
            player.Visible = true;
            OpenCamera(player);
        }

        private async void Capture1_Click(object sender, RoutedEventArgs e)
        {
            image = CameraHelper.CaptureImage(@"E:\1");
            Video.Visibility = Visibility.Hidden;
            FacePhoto.Visibility = Visibility.Visible;
            CloseCamera();
            if (await DetectPictureAndImformation(image) == true)
            {
                Add.IsEnabled = true;           
            }
            Capture1.IsEnabled = false;
            ReCapture1.IsEnabled = true;
        }

        //连接按钮
        private void Connect_Click(object sender, RoutedEventArgs e)
        {
            disconnect.IsEnabled = true;
            connect.IsEnabled = false;
            Capture2.IsEnabled = true;
            ReCapture2.IsEnabled = false;
            OpenCamera(player1);
            Video1.Visibility = Visibility.Visible;

        }
        //断开按钮
        private void DisConnect(object sender, RoutedEventArgs e)
        {
            disconnect.IsEnabled = false;
            connect.IsEnabled = true;
            ReCapture2.IsEnabled = false;
            Capture2.IsEnabled = false;
            Sign.IsEnabled = false;
            CloseCamera();
            Video1.Visibility = Visibility.Hidden;
        }

        private async void Capture2_Click(object sender, RoutedEventArgs e)
        {
            Capture2.IsEnabled = false;
            ReCapture2.IsEnabled = true;
            image = CameraHelper.CaptureImage(@"E:\1");
            Video1.Visibility = Visibility.Hidden;
            FacePhoto1.Visibility = Visibility.Visible;
            if (await DetectPicture(image) == true)
            {
                Sign.IsEnabled = true;
            }
            CloseCamera();
            Video1.Visibility = Visibility.Hidden;
        }

        private void ReCapture1_Click(object sender, RoutedEventArgs e)
        {
            player.Visible = true;
            Capture1.IsEnabled = true;
            ReCapture1.IsEnabled = false;
            Add.IsEnabled = false;
            OpenCamera(player);
            Video.Visibility = Visibility.Visible;
            FacePhoto.Visibility = Visibility.Collapsed;
        }

        private void ReCapture2_Click(object sender, RoutedEventArgs e)
        {
            ReCapture2.IsEnabled = false;
            Sign.IsEnabled = false;
            Capture2.IsEnabled = true;
            OpenCamera(player1);
            Video1.Visibility = Visibility.Visible;
            FacePhoto1.Visibility = Visibility.Collapsed;
        }

        private async void SelectFile_Click(object sender, RoutedEventArgs e)
        {
            var openDlg = new Microsoft.Win32.OpenFileDialog();
            openDlg.Filter = "JPEG Image(*.jpg)|*.jpg";
            openDlg.Multiselect = true;
            bool? result = openDlg.ShowDialog(this);
            // Return if canceled.
            if (!(bool)result)
            {
                MessageBox.Show("请至少选择一张照片");
                return;
            }

            // Display the image file.
            imagesPath = openDlg.FileNames;              //保存多种图片的路径
            foreach (string image in imagesPath)
            {
                if (await DetectPictureAndImformation(image) == false)         //检测人脸,如果有一张不符合则添加失败,
                {
                    FacePhoto.Visibility = Visibility.Collapsed;
                    return;
                }
            }    
            Add.IsEnabled = true;
        }

        private void UpdateDataBase()
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
           (new Table()).ShowDialog();
        }
    }

    public class User
    {
        public User()
        {
            Time = DateTime.Now;
        }
        
        /// <summary>
        /// 人员姓名
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 人员性别
        /// </summary>
        public string Sex { get; set; }
        /// <summary>
        /// 人员年龄
        /// </summary>
        public double Age { get; set; }
        
        /// <summary>
        /// 人员情感
        /// </summary>
        public string Emotion { get; set; }
        /// <summary>
        /// 签到状态
        /// </summary>
        public string State { get; set; }

        public DateTime Time { get; set; }



    }
    public class SqlHelper
    {
        private SqlConnection mycon;
        public SqlDataAdapter Adapter;
        public SqlHelper()
        {
            string con = "server=.;user=sa;password=123456; database=people;";  //这里是保存连接数据库的字符串

            mycon = new SqlConnection(con);                        //创建SQL连接对象

            mycon.Open();
            Adapter = new SqlDataAdapter("select * from people", mycon);
        }
        public void UpdateDataBase()
        {

            SqlCommandBuilder cb = new SqlCommandBuilder(Adapter);

            cb.GetUpdateCommand();
            DataTable dt = SetToDatatable.SetToDataTable(MainWindow.UserGroup);
            Adapter.Update(dt);
        }

        public class SetToDatatable
        {
            public SetToDatatable() { }
            public static DataTable SetToDataTable<T>(ObservableCollection<T> entitys)
            {

                //检查实体集合不能为空
                if (entitys == null || entitys.Count < 1)
                {
                    return new DataTable();
                }

                //取出第一个实体的所有Propertie
                Type entityType = entitys[0].GetType();
                PropertyInfo[] entityProperties = entityType.GetProperties();

                //生成DataTable的structure
                //生产代码中，应将生成的DataTable结构Cache起来，此处略
                DataTable dt = new DataTable("dt");
                for (int i = 0; i < entityProperties.Length; i++)
                {
                    dt.Columns.Add(entityProperties[i].Name, entityProperties[i].PropertyType);
                    //dt.Columns.Add(entityProperties[i].Name);
                }

                //将所有entity添加到DataTable中
                foreach (object entity in entitys)
                {
                    //检查所有的的实体都为同一类型
                    if (entity.GetType() != entityType)
                    {
                        throw new Exception("要转换的集合元素类型不一致");
                    }
                    object[] entityValues = new object[entityProperties.Length];
                    for (int i = 0; i < entityProperties.Length; i++)
                    {
                        entityValues[i] = entityProperties[i].GetValue(entity, null);

                    }
                    dt.Rows.Add(entityValues);
                }
                return dt;
            }
        }

    }

}




